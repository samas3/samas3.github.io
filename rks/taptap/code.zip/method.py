import base64
import io
import struct

import zipfile
import requests

from collections import OrderedDict
from requests.adapters import HTTPAdapter
from Crypto.Cipher import AES

from Crypto.Util import Padding


levels = ["EZ", "HD", "IN", "AT"]
difficulty = OrderedDict()
dict_fuzzy = {}
info = {}
info_by = {}
info_illustrator = {}
info_ez_desinger = {}
info_hd_designer = {}
info_in_desingner = {}
info_at_designer = {}

global_headers = {
    "X-LC-Id": "rAK3FfdieFob2Nn8Am",
    "X-LC-Key": "Qr9AEqtuoSVS3zeD6iVbM4ZC0AtkJcQ89tywVyi0",
    "User-Agent": "LeanCloud-CSharp-SDK/1.0.3",
    "Accept": "application/json",
}

key = base64.b64decode("6Jaa0qVAJZuXkZCLiOa/Ax5tIZVu+taKUN1V1nqwkks=")
iv = base64.b64decode("Kk/wisgNYwcAV8WVGMgyUw==")


def getBool(num, index):
    return bool(num & 1 << index)


class ByteReader:
    def __init__(self, data: bytes):
        self.data = data
        self.position = 0

    def readString(self):
        length = self.data[self.position]
        self.position += length + 1
        return self.data[self.position - length : self.position].decode()

    def readScoreAcc(self):
        self.position += 8
        scoreAcc = struct.unpack("if", self.data[self.position - 8 : self.position])
        return {"score": scoreAcc[0], "acc": scoreAcc[1]}

    def readRecord(self, songId):
        end_position = self.position + self.data[self.position] + 1
        self.position += 1
        exists = self.data[self.position]
        self.position += 1
        fc = self.data[self.position]
        self.position += 1
        diff = difficulty[songId]
        records = []
        song_names = info[songId]
        for level in range(len(diff)):
            if getBool(exists, level):
                scoreAcc = self.readScoreAcc()
                scoreAcc["level"] = levels[level]
                scoreAcc["fc"] = getBool(fc, level)
                scoreAcc["songId"] = songId
                scoreAcc["songname"] = song_names
                scoreAcc["difficulty"] = diff[level]
                scoreAcc["rks"] = (scoreAcc["acc"] - 55) / 45
                scoreAcc["rks"] = (
                    scoreAcc["rks"] * scoreAcc["rks"] * scoreAcc["difficulty"]
                )
                records.append(scoreAcc)
        self.position = end_position
        return records
    
    def getBit(data, index) :
        return bool(data & (1 << index))
    def readByte(self):
        res = self.data[self.position]
        self.position += 1
        return res
    def readVarInt(self):
        num = 0
        for i in range(5):
            num |= (self.data[self.position] & 0x7F) << 7 * i
            self.position += 1
            if self.data[self.position - 1] & 0x80 == 0:
                break
        return num
    def readShort(self):
        res = struct.unpack("h", self.data[self.position:self.position+2])[0]
        self.position += 2
        return res
global_save = ''
global_token = ''
class DataPackage:
    @staticmethod
    def LoadSave(url):
        global global_save
        resp = requests.get(url, headers=global_headers)
        if resp.status_code != 200:
            raise Exception("Network error.")
        data = resp.content
        global_save = data
    @staticmethod
    def GameReader(file):
        with zipfile.ZipFile(io.BytesIO(global_save)) as zips:
            with zips.open(file) as gameRecord_file:
                gameRecord_file.read(1)
                return decrypt_gameRecord(gameRecord_file.read())
'''
reader = DataPackage.GameReader(saveurl, 'user')
 showPlayerId: byte
 selfIntro: str
 avatar: str
 background: str
reader = DataPackage.GameReader(saveurl, 'settings')
 [multiHit, fcAPIndicator, hitSound, lowRes]: byte
 deviceName: str
 brightness: float
 musicVolume: float
 effectVolume: float
 hitSoundVolume: float
 soundOffset: float
 noteScale: float
reader = DataPackage.GameReader(saveurl, 'gameProgress')
 [isFirstRun, legacyChapterFinished, collectionTipShown, autoUnlockINTipShown]: byte
 completed: str
 songUpdateInfo: varint
 challengeModeRank: short
 money[5]: varint[5]
 unlockedSpasmodic: byte
 unlockedIgallta: byte
 unlockedRrharil: byte
 songRecordKey: byte
 unlockedRandomVarients: byte
 [c8unlockBegin, c8secondPhase, c8passed, _]: byte
 c8songUnlocked: byte
'''

def decrypt_gameRecord(gameRecord):
    gameRecord = AES.new(key, AES.MODE_CBC, iv).decrypt(gameRecord)
    return Padding.unpad(gameRecord, AES.block_size)


def parse_render_bests(gameRecord):
    records = []
    reader = ByteReader(gameRecord)
    total = reader.readVarInt()
    for _ in range(total):
        songId = reader.readString()[:-2]
        record = reader.readRecord(songId)
        records.extend(record)
    records.sort(key=lambda x: x["rks"], reverse=True)
    render = sorted(
            filter(lambda x: x["score"] == 1000000, records),
            key=lambda x: -x["difficulty"],
        )
    if len(render) > 2:
        render = render[:3]
    render.extend(records)
    return render

class BestsRender:
    @staticmethod
    def read_difficulty(path):
        difficulty.clear()
        with open(path, encoding="utf-8") as f:
            lines = f.readlines()
        for line in lines:
            line = line[:-1].split(",")
            diff = []
            for i in range(1, len(line)):
                diff.append(float(line[i]))
            difficulty[line[0]] = diff

    @staticmethod
    def read_playerInfo(path):
        info.clear()
        with open(path, encoding="utf-8") as f:
            lines = f.readlines()
        for line in lines:
            line = line[:-1].split("\\")
            infos = []
            for i in range(1, len(line)):
                infos.append(str(line[i]))
            info[line[0]] = infos[0]
            info_by[line[0]] = infos[1]
            info_illustrator[line[0]] = infos[2]
            info_ez_desinger[line[0]] = infos[3]
            info_hd_designer[line[0]] = infos[4]
            info_in_desingner[line[0]] = infos[5]
            try:
                info_at_designer[line[0]] = infos[6]
            except Exception:
                info_at_designer[line[0]] = ""

    @staticmethod
    def get_playerId():
        headers = global_headers.copy()
        headers["X-LC-Session"] = global_token
        response = requests.get(
            "https://rak3ffdi.cloud.tds1.tapapis.cn/1.1/users/me", headers=headers
        )
        result = response.json()["nickname"]
        return result
    @staticmethod
    def load_save():
        try:
            s = requests.session()
            s.mount("http://", HTTPAdapter(max_retries=3))
            s.mount("https://", HTTPAdapter(max_retries=3))
            headers = global_headers.copy()
            headers["X-LC-Session"] = global_token
            response = s.get(
                "https://rak3ffdi.cloud.tds1.tapapis.cn/1.1/classes/_GameSave",
                headers=headers,
                timeout=5,
            )
        except Exception as e:
            return None, "Network error."
        result = response.json()["results"][0]
        saveurl = result["gameFile"]["url"]
        DataPackage.LoadSave(saveurl)
    @staticmethod
    def get_summary():
        player_id = BestsRender.get_playerId()
        reader = DataPackage.GameReader('gameProgress')
        reader = ByteReader(reader)
        reader.readByte()
        reader.readString()
        reader.readVarInt()
        challengeModeRank = reader.readShort()
        money = []
        for i in range(5):
            money.append(reader.readVarInt())
        return {
            'player_id': player_id,
            'challengeModeRank': challengeModeRank,
            'money': money
        }

    @staticmethod
    def get_bests():
        gameRecord = DataPackage.GameReader('gameRecord')
        return parse_render_bests(gameRecord)

BestsRender.read_difficulty('difficulty.csv')
BestsRender.read_playerInfo('info.csv')
def set_token(token):
    global global_token
    global_token = token
    BestsRender.load_save()
def summary():
    return BestsRender.get_summary()
def b19():
    return BestsRender.get_bests()